package com.example.demo.sercice;

import java.util.List;

import com.example.demo.entity.Item;

public interface ItemService {
	
	public Item saveItem(Item item);

	public List<Item> fetchItemList();
	
	public Item fetchItemById(Long itemId);

	public void deleteItemById(Long itemId);
	
	public Item updateItem(Long itemId, Item item);



	





}



