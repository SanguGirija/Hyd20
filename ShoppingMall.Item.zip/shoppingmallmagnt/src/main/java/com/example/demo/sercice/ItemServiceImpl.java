package com.example.demo.sercice;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Item;
import com.example.demo.repository.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService{
	
@Autowired
private ItemRepository ir;

@Override
public Item saveItem(Item item) {
	return ir.save(item);
	
}

@Override
public List<Item> fetchItemList(){
	return ir.findAll();
}

@Override 
public Item fetchItemById(Long Id) {
	return ir.findById(Id).get();
}


@Override
public void deleteItemById(Long Id) {
	ir.deleteById(Id);
	
}

@Override
public Item updateItem(Long Id, Item item) {
	Item ma = ir.findById(Id).get();

	 if(Objects.nonNull(item.getItemName()) &&
		       !"".equalsIgnoreCase(item.getItemName())) {
		           ma.setItemName(item.getItemName());
		       }

		       if(Objects.nonNull(item.getItemPrice())) {
		               
		           ma.setItemPrice(item.getItemPrice());
		       }

       return ir.save(ma);
	
}


}


