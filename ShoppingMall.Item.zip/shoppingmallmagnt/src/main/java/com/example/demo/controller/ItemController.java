package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Item;
import com.example.demo.sercice.ItemService;


@RestController
public class ItemController {
	
@Autowired
private ItemService itemService;

 
   	@PostMapping("/item")
   	public Item saveItem(@RequestBody Item item) {
   		return itemService.saveItem(item);
}
    @GetMapping("/item")
    public List<Item> fetchItemList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return itemService.fetchItemList();

    }
    
        @GetMapping("/item/{id}")
        public Item fetchItemById(@PathVariable("id") Long Id){
              return itemService.fetchItemById(Id);
    }
    
    @DeleteMapping("/item/{id}")
    public String deleteItemById(@PathVariable("id") Long Id){
    	itemService.deleteItemById(Id);
        return "Item deleted Successfully!!";

    }
    
    @PutMapping("/item/{id}")
    public Item updateItemt(@PathVariable("id") Long id,
                                       @RequestBody Item item) {
        return itemService.updateItem(id,item);
    }

}